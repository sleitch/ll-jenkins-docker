#!/bin/bash
set -x

if [ "x${1}" = "x" ];
then
  exit 2
fi

TOKEN=${1}

FOUND=$(/usr/bin/grep -c "${TOKEN}" /etc/rsyslog.conf | /usr/bin/tr -d [:space:])

RESULT=0

if [ "x${FOUND}" = "x0" ]
then
  /usr/bin/echo "$template Logentries,\"${TOKEN} %HOSTNAME% %syslogtag%%msg%\n\"" >> /etc/rsyslog.conf
  let "RESULT += $?"
  /usr/bin/echo "*.* @@data.logentries.com:80;Logentries" >> /etc/rsyslog.conf
  let "RESULT += $?"
fi

exit $RESULT
