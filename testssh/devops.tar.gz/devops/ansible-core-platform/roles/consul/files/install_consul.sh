#!/bin/sh

PATH='/bin:/usr/bin'

if [ "x${1}" = "x" ];
then
  exit 2
fi

CONSUL_ARCHIVE="${1}_linux_amd64.zip"

# Add the binary

mkdir /tmp/consul
wget -P /tmp/consul/ https://dl.bintray.com/mitchellh/consul/$CONSUL_ARCHIVE 
unzip /tmp/consul/$CONSUL_ARCHIVE -d /tmp/consul/
cp /tmp/consul/consul "/usr/local/bin/consul-${1}"
rm /usr/local/bin/consul
ln -s "/usr/local/bin/consul-${1}" /usr/local/bin/consul
rm -rf /tmp/consul
