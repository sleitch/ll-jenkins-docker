#!/bin/bash
set -x
LOCAL_NS="nameserver 127.0.0.1"
FOUND=$(/usr/bin/grep -c "${LOCAL_NS}" /etc/resolv.conf | /usr/bin/tr -d [:space:])

RESULT=0

if [ "x${FOUND}" = "x0" ]
then
  /usr/bin/cp -a /etc/resolv.conf /etc/resolv.conf.bk
  let "RESULT += $?"
  /usr/bin/echo ${LOCAL_NS} | /usr/bin/cat - /etc/resolv.conf.bk > /etc/resolv.conf
  let "RESULT += $?"
fi

exit $RESULT
