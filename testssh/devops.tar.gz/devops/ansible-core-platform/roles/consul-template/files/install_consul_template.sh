#!/bin/sh

PATH='/bin:/usr/bin'

if [ "x${1}" = "x" ];
then
  exit 2
fi

CONSUL_FOLDER="consul-template_${1}_linux_amd64"
CONSUL_ARCHIVE="${CONSUL_FOLDER}.tar.gz" 

mkdir /tmp/consul
wget -P /tmp/consul/ https://github.com/hashicorp/consul-template/releases/download/v{1}/$CONSUL_ARCHIVE 
tar -xzf /tmp/consul/$CONSUL_ARCHIVE 
cp /tmp/consul/${CONSULE_FOLDER}/consul-template "/usr/local/bin/consul-template-${1}"
rm /usr/local/bin/consul-template
ln -s "/usr/local/bin/consul-template-${1}" /usr/local/bin/consul-template
rm -rf /tmp/consul
