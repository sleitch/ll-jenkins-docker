LeisureLink's ansible repository
===============================

This is LL's ansible repository containing playbooks and roles for deploying the Marketspan platform onto a CentOS 7 based environment.

The roles and playbooks attempt to define reasonable default values for many of the deployed components. There are, however, a number of
variables which for security reasons must be set only on the ansible CNC server or by the operator at runtime. The following
is a (at the moment non-exhaustive) list of private variables:

- ll_quay_robot_token: A token with read privleges to all quay.io docker image repositories that are intended to be deployed.
- ll_quay_robot: The username associated with the ll_quay_robot_token
- security_mongodb: The DNS name of the mongodb that the central auth service (authentic-api) will store its data in
- security_mongodb_port: The port number of the TLS connection for security_mongodb
- security_mongodb_name: The database name with authentic-api should use when communicating with security_mongodb
- logentries_token: An environment specific logentries token which has authority to send logs to our logentries.com account
- logentries_rsyslog_token: An environment specific logentries token which has authority to send logs to our logentries.com account, used for non-docker container logging
- authentic_priv_key: A file path to the environment's authentic private key
- authentic_pub_key: A file path to the environment's public key
- consul_gossip_psk: A pre shared key used for symmetric encryption of the data shared between consul nodes in the application cluster 
- authentic_issuer_name: The name of the ticker issuer (the name authentic places in generated tickets)
- authentic_issuer_audience: The name of the audience (client applications) for which signed tickers are intended 

# Example Executions

- ansible-playbook site.yml -i ~/local-hosts --extra-vars "@/host/src/secrets/dev-vars.yml" --become

# Issues and gotchas experienced

- docker 1.5.0-28 intermittently cannot pull from private repositories. The bug is due to RHEL specific patches, fix is forthcoming soon (as 2015-04-17) in docker 1.5.0-30+. Due
  this issue the version of docker installed on the application servers is **pinned** to docker-1.4.1-37.el7.centos.x86_64. Once an updated version of 1.5 or 1.6 is release please
  remove the yum version lock on docker.
  - *Also* due to this issue our logging containers have docker stats logging turn off because the docker stats API is not available v1.4.x
- docker (as of 1.5) cannot mount file volumes across symlinks. An example of this is the logger container which mounts /var/run/docker.sock, on CentOS 7 /var/run is a symlink
  for /run. In order to run the logger container it *must* mount /run/docker.sock.
- Consul configuration is finicky and the documentation does not cover which ports need to be exposed for hosts to talk to each. Review the consul tasks file 
  (roles/consul/tasks/main.yml) for which ports need to be exposed.
- Ansible does not (yet) cleanly handle pull some kinds of public docker images. The logentries docker container in particular must be pulled with the ansible state set to 
  'present' and not 'started' or it will break.
- There doesn't appear to be a way to define **external** services in consul without doing a manual HTTP PUT call against an agent's catalog. The core issue is that there doesn't
  appear to be a way to define virtual consul nodes using a JSON file.
- Our Rackspace cloud instances cannot talk to each other using their service net IPs (those beginning with 10...); this means that consul servers and agents must bind the 
  'non-private' 172... network interfaces.
- MongoDB SSL issues when connecting from a runner docker container, SSL validation gets broken and in some cases applications may need to turn off SSL certificate validation.
