Setup a new rackspace server for ansible
========================================

This guide assumes the user starts with a base CentOS 7 image in the Rackspace cloud. The basic setup steps
involve depoying the ansible management key and preventing root login.

1. Verify the environment management user folder has at least 3 files, create-manager.sh, manager-sudoer, and id_ecdsa.pub.
2. Use scp to copy the folder to the server. You will be prompted for the root password.
  - $ scp /some/path/ root@new.server.ip:~/
3. Log onto the server with the root account
  - $ ssh root@new.server.ip
4. Descend into the transfered folder execute create-manager.sh
  - $ cd ./path
  - $ ./create-manager.sh
5. Logout
  - $ exit
6. Attempt to login with the manager user
  - $ manager@new.server.ip
7. If the login was successful, then verify the user's ability to use sudo
  - $ sudo -l
  - There should be a line that looks like: "(ALL) NOPASSWD: ALL"
8. Clean up the originally transferred setup folder
  - $ sudo rm -r /root/path

All done, the server can be accessed and configured using the manager user
