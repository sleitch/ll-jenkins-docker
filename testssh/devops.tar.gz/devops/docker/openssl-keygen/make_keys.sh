#!/bin/bash

# usage
show_help() {
    cat << EOF
Usage: docker run --volumes-from [SOURCE] quay.io/leisurelink/openssl-keygen [KEYNAME] [PATH]
Create a new private/public key pair and save them in the specified output directory. 
EOF
}

key_name=""

if [[ $0 == *"make_keys.sh" ]]; then
    key_name="$1"
    shift
else
    key_name="$0"
fi

target_dir=${1%/}

if [[ -z "$key_name" ]]; then
    echo Keypair name not provided.
    show_help
    exit 1
elif ! [[ -d $target_dir ]]; then
    echo $target_dir is not a directory.
    show_help
    exit 1
else
    openssl genrsa -out "$target_dir/$key_name.pem" 4096
    openssl rsa -pubout -in "$target_dir/$key_name.pem" -out "$target_dir/$key_name.pub"
fi

