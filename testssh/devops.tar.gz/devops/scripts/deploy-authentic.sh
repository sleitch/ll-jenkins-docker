#!/bin/bash
if [ "$1" != "dev" -a "$1" != "prod" ];
then
  echo "Usage: deploy-authentic.sh env-type"
  echo "Deploys authentic in the environment specified. Valid env-type values: dev, prod"
  exit 1
fi

set -x
ansible-playbook ~/devops/ansible-core-platform/authentic.yml -i ~/provision/$1/$1-hosts --extra-vars "@/home/manager/provision/$1/$1-vars.yml" --become
