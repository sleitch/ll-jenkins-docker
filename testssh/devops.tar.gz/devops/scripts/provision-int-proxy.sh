#!/bin/bash
if [ "$1" != "dev" -a "$1" != "prod" ];
then
  echo "Usage: provision-int-proxy.sh env-type"
  echo "Provisions the int proxy layer in the environment specified. Valid env-type values: dev, prod"
  exit 1
fi

ansible-playbook ~/devops/ansible-core-platform/int_proxy.yml -i ~/provision/$1/$1-hosts --extra-vars "@/home/manager/provision/$1/$1-vars.yml" --become
