#!/bin/bash
if [ "$1" != "dev" -a "$1" != "prod" ];
then
  echo "Usage: deploy-shared-auth.sh env-type"
  echo "Deploys shared-auth in the environment specified. Valid env-type values: dev, prod"
  exit 1
fi

ansible-playbook ~/devops/ansible-core-platform/shared-auth.yml -i ~/provision/$1/$1-hosts --extra-vars "@/home/manager/provision/$1/$1-vars.yml" --become
