#!/bin/bash
if [ "$1" != "dev" -a "$1" != "prod" ];
then
  echo "Usage: provision-site.sh env-type"
  echo "Provisions the site in the environment specified. Valid env-type values: dev, prod"
  exit 1
fi

set -x
ansible-playbook ~/devops/ansible-core-platform/site.yml -i ~/provision/$1/$1-hosts --extra-vars "@/home/manager/provision/$1/$1-vars.yml" --become
