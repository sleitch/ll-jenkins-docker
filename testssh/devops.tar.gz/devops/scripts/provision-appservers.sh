#!/bin/bash
if [ "$1" != "dev" -a "$1" != "prod" ];
then
  echo "Usage: provision-appservers.sh env-type"
  echo "Provisions all app servers in the environment specified. Valid env-type values: dev, prod"
  exit 1
fi

set -x
ansible-playbook ~/devops/ansible-core-platform/webservers.yml -i ~/provision/$1/$1-hosts --extra-vars "@/home/manager/provision/$1/$1-vars.yml" --become
