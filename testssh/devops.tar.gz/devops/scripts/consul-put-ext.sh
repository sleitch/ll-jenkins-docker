#!/bin/bash
set -x
if [ ! -x /usr/bin/curl ];
then
  echo "Need the curl command to operate"
  exit 1
fi

if [ "${1}x" = "x" ];
then
  echo "Usage: consul-put-ext.sh file-name"
  echo "consul-put-ext.sh PUTs a node and service to the local agent's catalog"
  exit 1
fi
/usr/bin/curl -v -H "Content-Type: application/json" -X PUT --data "@${1}" http://127.0.0.1:8500/v1/catalog/register
