scripts
======

Bash and cmd scripts for LL environment administration

- genrsa.sh: A bash script meant to be run on a host with (a recent version of) openssl installed. The script accepts two arguments, the first is
  used as the name of generated RSA private key and the second is used as the name of the public key.
- consul-put.sh: A short bash script meant to be run on a host in a LL core platform cluster. The script takes a single argument, a file path to a
  JSON contain that contains an external service definition. The script is essentially a 1-liner and is only meant to save the user some typing. You may
  need to hit ctrl-c after the script is run to cleanup.
