#!/bin/sh

if [ "x${1}" = "x" -o "x${2}" = "x" ];
then
  echo "Usage: genrsa.sh private-key-name public-key-name"
  echo "genrsa.sh creates a 2048 bit RSA public-private key pair with the specific names"
  exit 1
fi

openssl genpkey -outform PEM -out ${1} -algorithm rsa -pkeyopt rsa_keygen_bits:2048
openssl rsa -inform PEM -in ${1} -pubout -out ${2}
